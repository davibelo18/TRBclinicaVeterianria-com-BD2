
package model;

import java.time.LocalDate;

public class AnimalBuilder {

    private String nome;
    private String especie;
    private String raca;
    private LocalDate dataNascimento;
    private String sexo;
    private int tutorID;
    private Integer veterinarioID;

    public AnimalBuilder nome(String nome) {
        this.nome = nome;
        return this;
    }
    public AnimalBuilder especie(String especie) {
        this.especie = especie;
        return this;
    }
    public AnimalBuilder raca(String raca) {
        this.raca = raca;
        return this;
    }
    public AnimalBuilder dataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
        return this;
    }
    public AnimalBuilder sexo(String sexo) {
        this.sexo = sexo;
        return this;
    }
    public AnimalBuilder tutorID(int tutorID) {
        this.tutorID = tutorID;
        return this;
    }
    public AnimalBuilder veterinarioID(Integer veterinarioID) {
        this.veterinarioID = veterinarioID;
        return this;
    }
    public Animal build() {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("Nome do animal obrigatório.");
        }

        if (especie == null || especie.isBlank()) {
            throw new IllegalArgumentException("Espécie obrigatória.");
        }

        if (tutorID <= 0) {
            throw new IllegalArgumentException("Selecione um tutor.");
        }
        Animal animal = new Animal();
        animal.setNome(nome);
        animal.setEspecie(especie);
        animal.setRaca(raca);
        animal.setDataNascimento(dataNascimento);
        animal.setSexo(sexo);
        animal.setTutorID(tutorID);
        animal.setVeterinarioID(veterinarioID);

        return animal;
    }
}
