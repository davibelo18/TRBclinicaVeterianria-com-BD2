package Service;

import Factory.PostgresTutorDAOFactory;
import dao.TutorDAO;
import model.Tutor;
import java.sql.SQLException;
import java.util.List;

public class TutorService {
    private final TutorDAO tutorDAO;

    public TutorService() {
        this.tutorDAO = new PostgresTutorDAOFactory().criarDAO();
    }

    // Cadastra um novo tutor
    public void cadastrar(Tutor tutor) throws SQLException {
        validarTutor(tutor);

        // Evita CPF vazio no banco, o CPF pode ser NULL
        tutor.setCpf(normalizar(tutor.getCpf()));
        tutor.setEmail(normalizar(tutor.getEmail()));
        tutor.setEndereco(normalizar(tutor.getEndereco()));

        tutorDAO.insere(tutor);
    }

    // Consulta todos os tutores
    public List<Tutor> listarTodos() throws SQLException {
        return tutorDAO.listaTodos();
    }

    // Atualiza um tutor existente
    public void atualizar(Tutor tutor) throws SQLException {
        if (tutor.getTutorID() <= 0) {
            throw new IllegalArgumentException("Tutor inválido.");
        }

        validarTutor(tutor);

        tutor.setCpf(normalizar(tutor.getCpf()));
        tutor.setEmail(normalizar(tutor.getEmail()));
        tutor.setEndereco(normalizar(tutor.getEndereco()));

        tutorDAO.atualiza(tutor);
    }

    // Exclui um tutor
    public void excluir(Tutor tutor) throws SQLException {
        if (tutor == null || tutor.getTutorID() <= 0) {
            throw new IllegalArgumentException("Selecione um tutor válido.");
        }

       tutorDAO.remove(tutor);
    }

    // Regras de negócio
    private void validarTutor(Tutor tutor) {
        if (tutor == null) {
            throw new IllegalArgumentException("Tutor não informado.");
        }

        if (tutor.getNome() == null || tutor.getNome().isBlank()) {
            throw new IllegalArgumentException("O nome é obrigatório.");
        }

        if (tutor.getTelefone() == null || tutor.getTelefone().isBlank()) {
            throw new IllegalArgumentException("O telefone é obrigatório.");
        }

        String cpf = tutor.getCpf();

        if (cpf != null && !cpf.isBlank() && !cpf.matches("\\d{11}")) {
            throw new IllegalArgumentException(
                    "O CPF deve conter exatamente 11 números."
            );
        }

        tutor.setNome(tutor.getNome().trim());
        tutor.setTelefone(tutor.getTelefone().trim());
    }

    private String normalizar(String valor) {
        return valor == null || valor.isBlank() ? null : valor.trim();
    }
}
