package Service;
import Factory.*;
import dao.AnimalDAO;
import dao.AnimalDBDAO;
import dao.TutorDAO;
import dao.TutorDBDAO;
import dao.VeterinarioDAO;
import dao.VeterinarioDBDAO;
import model.Animal;
import model.Tutor;
import model.Veterinario;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class AnimalService {

    private final AnimalDAO animalDAO;
    private final TutorDAO tutorDAO;
    private final VeterinarioDAO veterinarioDAO;

    public AnimalService() {

        this.animalDAO = new PostgresAnimalDAOFactory().criarDAO();
        this.tutorDAO = new PostgresTutorDAOFactory().criarDAO();
        this.veterinarioDAO = new PostgresVeterinarioDAOFactory().criarDAO();
    }

    public void cadastrar(Animal animal) throws SQLException {
        validarAnimal(animal);
        animalDAO.insere(animal);
    }

    public List<Animal> listarTodos() throws SQLException {
        return animalDAO.listaTodos();
    }

    public List<Tutor> listarTutores() throws SQLException {
        return tutorDAO.listaTodos();
    }

    public List<Veterinario> listarVeterinarios() throws SQLException {
        return veterinarioDAO.listaTodos();
    }

    public void atualizar(Animal animal) throws SQLException {
        if (animal == null || animal.getAnimalID() <= 0) {
            throw new IllegalArgumentException("Selecione um animal válido.");
        }

        validarAnimal(animal);
        animalDAO.atualiza(animal);
    }

    public void excluir(Animal animal) throws SQLException {
        if (animal == null || animal.getAnimalID() <= 0) {
            throw new IllegalArgumentException("Selecione um animal válido.");
        }

        animalDAO.remove(animal);
    }

    public List<Animal> listarPorTutor(int tutorID) throws SQLException {
        if (tutorID <= 0) {
            throw new IllegalArgumentException("Tutor inválido.");
        }

        return animalDAO.listaPorTutor(tutorID);
    }

    public List<Animal> listarPorVeterinario(int veterinarioID) throws SQLException {
        if (veterinarioID <= 0) {
            throw new IllegalArgumentException("Veterinário inválido.");
        }

        return animalDAO.listaPorVeterinario(veterinarioID);
    }

    private void validarAnimal(Animal animal) {
        if (animal == null) {
            throw new IllegalArgumentException("Animal não informado.");
        }

        if (animal.getNome() == null || animal.getNome().isBlank()) {
            throw new IllegalArgumentException("O nome do animal é obrigatório.");
        }

        if (animal.getEspecie() == null || animal.getEspecie().isBlank()) {
            throw new IllegalArgumentException("A espécie é obrigatória.");
        }

        if (animal.getTutorID() <= 0) {
            throw new IllegalArgumentException("Selecione um tutor.");
        }

        if (animal.getDataNascimento() != null &&
                animal.getDataNascimento().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("A data de nascimento não pode ser futura.");
        }

        if (animal.getSexo() != null &&
                !animal.getSexo().equals("Macho") &&
                !animal.getSexo().equals("Fêmea")) {
            throw new IllegalArgumentException("Selecione um sexo válido.");
        }

        animal.setNome(animal.getNome().trim());
        animal.setEspecie(animal.getEspecie().trim());
        animal.setRaca(normalizar(animal.getRaca()));
    }

    private String normalizar(String valor) {
        return valor == null || valor.isBlank() ? null : valor.trim();
    }
}