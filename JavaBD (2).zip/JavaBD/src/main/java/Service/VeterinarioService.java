package Service;

import Factory.*;
import dao.VeterinarioDAO;
import dao.AnimalDAO;
import dao.TutorDAO;
import model.Veterinario;
import model.Animal;
import model.Tutor;

import java.sql.SQLException;
import java.util.List;

public class VeterinarioService {

    private final VeterinarioDAO veterinarioDAO;
    private final AnimalDAO animalDAO;
    private final TutorDAO tutorDAO;

    public VeterinarioService() {

        this.animalDAO = new PostgresAnimalDAOFactory().criarDAO();

        this.tutorDAO = new PostgresTutorDAOFactory().criarDAO();

        this.veterinarioDAO = new PostgresVeterinarioDAOFactory().criarDAO();
    }

    public void cadastrar(Veterinario veterinario) throws SQLException {
        validarVeterinario(veterinario);
        veterinarioDAO.insere(veterinario);
    }

    public List<Veterinario> listarTodos() throws SQLException {
        return veterinarioDAO.listaTodos();
    }

    public List<Tutor> listarTutores() throws SQLException {
        return tutorDAO.listaTodos();
    }

    public List<Animal> listarAnimaisPorVeterinario(int veterinarioID)
            throws SQLException {

        if (veterinarioID <= 0) {
            throw new IllegalArgumentException("Veterinário inválido.");
        }

        return animalDAO.listaPorVeterinario(veterinarioID);
    }

    public void atualizar(Veterinario veterinario) throws SQLException {
        if (veterinario == null || veterinario.getId_veterinario() <= 0) {
            throw new IllegalArgumentException("Selecione um veterinário válido.");
        }

        validarVeterinario(veterinario);
        veterinarioDAO.atualiza(veterinario);
    }

    public void excluir(Veterinario veterinario) throws SQLException {
        if (veterinario == null || veterinario.getId_veterinario() <= 0) {
            throw new IllegalArgumentException("Selecione um veterinário válido.");
        }

        veterinarioDAO.remove(veterinario);
    }

    private void validarVeterinario(Veterinario veterinario) {
        if (veterinario == null) {
            throw new IllegalArgumentException("Veterinário não informado.");
        }

        if (veterinario.getNome() == null || veterinario.getNome().isBlank()) {
            throw new IllegalArgumentException("O nome é obrigatório.");
        }

        if (veterinario.getCrmv() == null || veterinario.getCrmv().isBlank()) {
            throw new IllegalArgumentException("O CRMV é obrigatório.");
        }

        veterinario.setNome(veterinario.getNome().trim());
        veterinario.setCrmv(veterinario.getCrmv().trim());
        veterinario.setTelefone(normalizar(veterinario.getTelefone()));
        veterinario.setEmail(normalizar(veterinario.getEmail()));
    }

    private String normalizar(String valor) {
        return valor == null || valor.isBlank() ? null : valor.trim();
    }
}