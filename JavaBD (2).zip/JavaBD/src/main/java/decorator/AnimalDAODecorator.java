
package decorator;

import dao.AnimalDAO;
import model.Animal;

import java.sql.SQLException;
import java.util.List;

public class AnimalDAODecorator implements AnimalDAO {

    private final AnimalDAO dao;

    public AnimalDAODecorator(AnimalDAO dao) {
        this.dao = dao;
    }

    @Override
    public void insere(Animal animal) throws SQLException {
        System.out.println("[LOG] Cadastrando animal: " + animal.getNome());

        dao.insere(animal);

        System.out.println("[LOG] Animal cadastrado com sucesso.");
    }

    @Override
    public void atualiza(Animal animal) throws SQLException {
        System.out.println("[LOG] Atualizando animal: " + animal.getNome());

        dao.atualiza(animal);

        System.out.println("[LOG] Animal atualizado com sucesso.");
    }

    @Override
    public void remove(Animal animal) throws SQLException {
        System.out.println("[LOG] Excluindo animal: " + animal.getNome());

        dao.remove(animal);

        System.out.println("[LOG] Animal excluído com sucesso.");
    }

    @Override
    public Animal buscaPorCodigo(int animalId) throws SQLException {
        System.out.println("[LOG] Buscando animal: " + animalId);

        return dao.buscaPorCodigo(animalId);
    }

    @Override
    public List<Animal> listaTodos() throws SQLException {
        System.out.println("[LOG] Listando todos os animais.");

        return dao.listaTodos();
    }

    @Override
    public List<Animal> listaPorTutor(int tutorId) throws SQLException {
        System.out.println("[LOG] Listando animais do tutor: " + tutorId);

        return dao.listaPorTutor(tutorId);
    }

    @Override
    public List<Animal> listaPorVeterinario(int veterinarioId)
            throws SQLException {
        System.out.println("[LOG] Listando animais do veterinário: " + veterinarioId);

        return dao.listaPorVeterinario(veterinarioId);
    }
}
