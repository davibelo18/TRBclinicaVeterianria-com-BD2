
package Factory;

public abstract class DAOFactory<T> {

    public abstract T criarDAO();

}
