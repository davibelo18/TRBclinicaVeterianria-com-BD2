
package Factory;

import dao.TutorDAO;
import dao.TutorDBDAO;

public class PostgresTutorDAOFactory extends DAOFactory<TutorDAO> {

    @Override
    public TutorDAO criarDAO() {
        return new TutorDBDAO();
    }
}
