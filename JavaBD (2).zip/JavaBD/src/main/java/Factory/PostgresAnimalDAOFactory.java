
package Factory;

import dao.AnimalDAO;
import dao.AnimalDBDAO;
import decorator.AnimalDAODecorator;

public class PostgresAnimalDAOFactory extends DAOFactory<AnimalDAO> {

    @Override
    public AnimalDAO criarDAO() {
        return new AnimalDAODecorator(new AnimalDBDAO());
    }
}
