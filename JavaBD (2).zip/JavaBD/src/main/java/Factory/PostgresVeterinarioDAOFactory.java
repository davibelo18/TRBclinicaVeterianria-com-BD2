
package Factory;

import dao.VeterinarioDAO;
import dao.VeterinarioDBDAO;

public class PostgresVeterinarioDAOFactory extends DAOFactory<VeterinarioDAO> {

    @Override
    public VeterinarioDAO criarDAO() {
        return new VeterinarioDBDAO();
    }
}
